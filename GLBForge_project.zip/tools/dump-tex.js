const fs=require('fs'); globalThis.GF={};
for (const f of ['inflate','zip','bcn','ftex']) require('../web/js/'+f+'.js');
const GF=globalThis.GF; const z=GF.Zip.openZip(new Uint8Array(fs.readFileSync(process.argv[2])));
fs.mkdirSync(process.argv[3],{recursive:true});
for (const e of z.entries) if (e.name.toLowerCase().endsWith('.ftex')) {
  try { const t=GF.Ftex.readFtex(z.read(e)); const n=e.name.split('/').slice(-2).join('_').replace('#','');
    fs.writeFileSync(process.argv[3]+'/'+n+'.rgba',t.rgba); fs.writeFileSync(process.argv[3]+'/'+n+'.json',JSON.stringify({f:t.format,w:t.width,h:t.height,src:e.name}));
  } catch(err){ console.log('ERR',e.name,err.message); }
}
