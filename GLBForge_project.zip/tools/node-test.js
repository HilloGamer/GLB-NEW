// Uji inti konversi di Node: node tools/node-test.js <zip> <outDir>
const fs = require('fs'), path = require('path');
globalThis.GF = {};
for (const f of ['inflate', 'zip', 'bcn', 'ftex', 'fpk', 'fmdl', 'png', 'glb', 'convert']) require('../web/js/' + f + '.js');
const GF = globalThis.GF;
(async () => {
  const zipPath = process.argv[2], outDir = process.argv[3] || 'out_node';
  fs.mkdirSync(outDir, { recursive: true });
  const t0 = Date.now(), buf = new Uint8Array(fs.readFileSync(zipPath));
  const z = GF.Zip.openZip(buf);
  const files = z.entries.map(e => ({ path: e.name, data: z.read(e) }));
  console.log('zip ok:', files.length, 'file', Date.now() - t0, 'ms');
  const pkg = GF.Convert.openPackage(files, console.log);
  console.log('model:', pkg.models.map(m => m.name).join(', '), '| tekstur:', pkg.textureCount);
  const prepared = pkg.models.map(m => GF.Convert.prepareModel(m, pkg.getTexture, console.log));
  for (const p of prepared) {
    console.log(p.name, 'mesh:', p.draw.map(d => d.name + '(' + d.positions.length / 3 + 'v)').join(', '), '| dilewati:', p.skipped.join(', ') || '-');
    const glb = await GF.Convert.exportGlb([p]);
    fs.writeFileSync(path.join(outDir, p.name + '.glb'), glb);
    console.log('  ->', p.name + '.glb', (glb.length / 1e6).toFixed(2), 'MB', Date.now() - t0, 'ms');
  }
  const all = await GF.Convert.exportGlb(prepared);
  fs.writeFileSync(path.join(outDir, 'gabungan.glb'), all); console.log('gabungan.glb', (all.length / 1e6).toFixed(2), 'MB');
})().catch(e => { console.error('GAGAL', e); process.exit(1); });
