// Uji mandiri tanpa file pengguna: inflate/zip/png harus benar. Dipakai di CI.
const zlib = require('zlib'); globalThis.GF = {};
for (const f of ['inflate', 'zip', 'bcn', 'png']) require('../web/js/' + f + '.js');
const GF = globalThis.GF; let bad = 0;
const data = Buffer.alloc(300000); for (let i = 0; i < data.length; i++) data[i] = (i * 7 + (i >> 5)) & 255;
for (const lvl of [0, 1, 9]) {
  const out = GF.Inflate.inflateRaw(new Uint8Array(zlib.deflateRawSync(data, { level: lvl })), 0);
  if (Buffer.compare(Buffer.from(out), data) !== 0) { console.log('inflate GAGAL level', lvl); bad++; }
}
const px = GF.Bcn.decode(11, new Uint8Array(16 * 4), 8, 8); if (px.length !== 256) bad++;
console.log(bad ? 'SELFTEST GAGAL' : 'selftest OK'); process.exit(bad ? 1 : 0);
