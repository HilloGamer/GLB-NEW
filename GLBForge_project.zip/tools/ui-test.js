// Uji UI nyata di Chromium headless: node tools/ui-test.js <zip>
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path'), fs = require('fs');
(async () => {
  const b = await chromium.launch({ args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist', '--use-angle=swiftshader'] });
  const p = await b.newPage({ viewport: { width: 412, height: 915 }, deviceScaleFactor: 2 });
  p.on('console', m => { if (m.type() === 'error') console.log('[console.error]', m.text()); });
  p.on('pageerror', e => console.log('[pageerror]', e.message));
  await p.goto('file://' + path.resolve('web/index.html'));
  await p.setInputFiles('#file', process.argv[2]);
  await p.waitForFunction(() => document.getElementById('log').textContent.includes('Selesai') || document.getElementById('log').textContent.includes('GAGAL'), null, { timeout: 120000 });
  console.log(await p.textContent('#log'));
  await p.waitForTimeout(800);
  fs.mkdirSync('shots', { recursive: true });
  await p.screenshot({ path: 'shots/ui_all.png', fullPage: true });
  // putar & zoom
  const box = await (await p.$('#cv')).boundingBox();
  await p.mouse.move(box.x + box.width / 2, box.y + box.height / 2); await p.mouse.down(); await p.mouse.move(box.x + box.width / 2 - 140, box.y + box.height / 2, { steps: 8 }); await p.mouse.up();
  await p.waitForTimeout(500); await (await p.$('#cv')).screenshot({ path: 'shots/ui_rot.png' });
  // simpan
  const [dl] = await Promise.all([p.waitForEvent('download', { timeout: 120000 }), p.click('#save')]);
  await dl.saveAs('shots/' + dl.suggestedFilename()); console.log('download:', dl.suggestedFilename(), fs.statSync('shots/' + dl.suggestedFilename()).size);
  console.log(await p.textContent('#saveInfo'));
  await b.close();
})().catch(e => { console.error('UI TEST GAGAL', e); process.exit(1); });
