import re
h=open('web/index.html').read()
css=open('web/style.css').read()
h=h.replace('<link rel="stylesheet" href="style.css">','<style>'+css+'</style>')
def sub(m):
    return '<script>'+open('web/'+m.group(1)).read().replace('</script>','<\\/script>')+'</script>'
h=re.sub(r'<script src="([^"]+)"></script>',sub,h)
open('/mnt/user-data/outputs/glbforge_v2.html','w').write(h)
print(len(h))
