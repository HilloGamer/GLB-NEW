package app.glbforge

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import java.io.OutputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private var chooserCallback: ValueCallback<Array<Uri>>? = null
    private var saveStream: OutputStream? = null

    private companion object {
        const val REQ_PICK = 1001
        const val REQ_SAVE = 1002
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)

        // Disajikan lewat https://appassets.androidplatform.net agar dianggap secure context
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                chooserCallback?.onReceiveValue(null)
                chooserCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                }
                return try {
                    startActivityForResult(intent, REQ_PICK); true
                } catch (e: Exception) {
                    chooserCallback = null; false
                }
            }
        }
        web.addJavascriptInterface(Bridge(), "AndroidBridge")
        web.loadUrl("https://appassets.androidplatform.net/index.html")
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }

    inner class Bridge {
        @JavascriptInterface
        fun beginSave(name: String) {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "model/gltf-binary"
                    putExtra(Intent.EXTRA_TITLE, name)
                }
                try { startActivityForResult(intent, REQ_SAVE) } catch (e: Exception) { js("window.__gfSaveReady(false)") }
            }
        }

        @JavascriptInterface
        fun writeChunk(b64: String) {
            saveStream?.write(Base64.decode(b64, Base64.DEFAULT))
        }

        @JavascriptInterface
        fun endSave() {
            var ok = true
            try { saveStream?.flush(); saveStream?.close() } catch (e: Exception) { ok = false }
            saveStream = null
            js("window.__gfSaveDone($ok)")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_PICK -> {
                var uris: Array<Uri>? = null
                if (resultCode == RESULT_OK && data != null) {
                    val clip = data.clipData
                    uris = if (clip != null) Array(clip.itemCount) { clip.getItemAt(it).uri }
                    else data.data?.let { arrayOf(it) }
                }
                chooserCallback?.onReceiveValue(uris)
                chooserCallback = null
            }
            REQ_SAVE -> {
                val uri = data?.data
                if (resultCode == RESULT_OK && uri != null) {
                    try {
                        saveStream = contentResolver.openOutputStream(uri, "wt")
                        js("window.__gfSaveReady(true)")
                    } catch (e: Exception) { js("window.__gfSaveReady(false)") }
                } else js("window.__gfSaveReady(false)")
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
