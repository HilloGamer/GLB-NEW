# GLB Forge 3D — FMDL → GLB

Aplikasi Android (WebView) yang mengubah model PES/Fox Engine (`.fpk`/`.fmdl` + `.ftex`) menjadi `.glb`,
lengkap dengan pratinjau 3D langsung. Semua diproses di perangkat.

## Fitur
- Baca ZIP / FPK / FMDL / FTEX
- Decoder tekstur sendiri: BC1, BC3, BC7 (tidak bergantung dukungan browser)
- Tekstur kulit, rambut, normal map; skeleton + skinning masuk ke GLB
- Viewer WebGL: satu jari putar, dua jari zoom

## Membangun APK (tanpa Android Studio)
1. Buat repo GitHub, unggah seluruh isi folder ini.
2. Buka tab **Actions** → workflow **Build APK** → tunggu selesai.
3. Unduh artefak **GLBForge-debug-apk**, pasang `app-debug.apk` di ponsel.

## Membangun lokal
Android Studio: buka folder `android/`, jalankan. Atau `cd android && gradle assembleDebug` (JDK 17, Gradle 8.7).

## Uji di komputer
- `node tools/node-test.js file.zip keluaran/` — konversi lewat Node
- Buka `web/index.html` di Chrome desktop untuk mencoba UI

## Keterbatasan
- Mesh tanpa tekstur yang tersedia (eyeline, collar_ao, eyelash) dilewati
- Tekstur yang mip utamanya ada di `.ftexs` belum didukung
- Arah hijau normal map belum dipastikan: ada opsi "Balik sumbu Y"
