/* GLB Forge — penulis GLB (glTF 2.0 biner) dengan skeleton + skinning */
(function (G) {
  'use strict';
  function bytesOf(ta) { return new Uint8Array(ta.buffer, ta.byteOffset, ta.byteLength); }
  class Builder {
    constructor() { this.chunks = []; this.size = 0; this.bufferViews = []; this.accessors = []; this.images = []; this.textures = []; this.materials = []; this.meshes = []; this.nodes = []; this.skins = []; this.scene = []; }
    view(u8, target) {
      const pad = (4 - (this.size % 4)) % 4;
      if (pad) { this.chunks.push(new Uint8Array(pad)); this.size += pad; }
      const bv = { buffer: 0, byteOffset: this.size, byteLength: u8.length };
      if (target) bv.target = target;
      this.chunks.push(u8); this.size += u8.length; this.bufferViews.push(bv); return this.bufferViews.length - 1;
    }
    accessor(ta, ctype, type, count, target, minmax, normalized) {
      const a = { bufferView: this.view(bytesOf(ta), target), componentType: ctype, count, type };
      if (normalized) a.normalized = true;
      if (minmax) { const n = ta.length / count, mn = new Array(n).fill(Infinity), mx = new Array(n).fill(-Infinity); for (let i = 0; i < count; i++) for (let k = 0; k < n; k++) { const v = ta[i * n + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; } a.min = mn; a.max = mx; }
      this.accessors.push(a); return this.accessors.length - 1;
    }
    image(bytes, mime) {
      this.images.push({ bufferView: this.view(bytes), mimeType: mime });
      this.textures.push({ sampler: 0, source: this.images.length - 1 }); return this.textures.length - 1;
    }
    finish() {
      const j = { asset: { version: '2.0', generator: 'GLB Forge' }, scene: 0, scenes: [{ nodes: this.scene }], nodes: this.nodes, meshes: this.meshes, accessors: this.accessors, bufferViews: this.bufferViews, buffers: [{ byteLength: this.size + ((4 - this.size % 4) % 4) }] };
      if (this.materials.length) j.materials = this.materials;
      if (this.images.length) { j.images = this.images; j.textures = this.textures; j.samplers = [{ magFilter: 9729, minFilter: 9987, wrapS: 10497, wrapT: 10497 }]; }
      if (this.skins.length) j.skins = this.skins;
      let js = new TextEncoder().encode(JSON.stringify(j)); const jp = (4 - js.length % 4) % 4;
      if (jp) { const t = new Uint8Array(js.length + jp).fill(0x20); t.set(js); js = t; }
      const binLen = this.size + ((4 - this.size % 4) % 4), total = 12 + 8 + js.length + 8 + binLen;
      const out = new Uint8Array(total), dv = new DataView(out.buffer);
      dv.setUint32(0, 0x46546C67, true); dv.setUint32(4, 2, true); dv.setUint32(8, total, true);
      dv.setUint32(12, js.length, true); dv.setUint32(16, 0x4E4F534A, true); out.set(js, 20);
      let o = 20 + js.length; dv.setUint32(o, binLen, true); dv.setUint32(o + 4, 0x004E4942, true); o += 8;
      for (const c of this.chunks) { out.set(c, o); o += c.length; }
      return out;
    }
  }

  /**
   * models: hasil Convert.prepareModel(). opts.encode(tex, kind) -> {bytes, mime}
   */
  async function buildGlb(models, opts) {
    const b = new Builder(), matCache = new Map(), texCache = new Map();
    async function texIndex(key, make) {
      if (texCache.has(key)) return texCache.get(key);
      const { bytes, mime } = await make(); const i = b.image(bytes, mime); texCache.set(key, i); return i;
    }
    for (const model of models) {
      const nb = model.bones.length, base = b.nodes.length;
      model.bones.forEach(bn => {
        const p = bn.parent >= 0 ? model.bones[bn.parent].world : [0, 0, 0];
        b.nodes.push({ name: bn.name, translation: [bn.world[0] - p[0], bn.world[1] - p[1], bn.world[2] - p[2]] });
      });
      model.bones.forEach((bn, i) => { if (bn.parent >= 0) (b.nodes[base + bn.parent].children = b.nodes[base + bn.parent].children || []).push(base + i); else b.scene.push(base + i); });
      const ibm = new Float32Array(nb * 16);
      model.bones.forEach((bn, i) => { const m = ibm.subarray(i * 16, i * 16 + 16); m[0] = m[5] = m[10] = m[15] = 1; m[12] = -bn.world[0]; m[13] = -bn.world[1]; m[14] = -bn.world[2]; });
      const skin = { joints: Array.from({ length: nb }, (_, i) => base + i), inverseBindMatrices: b.accessor(ibm, 5126, 'MAT4', nb) };
      const rootBone = model.bones.findIndex(x => x.parent < 0); if (rootBone >= 0) skin.skeleton = base + rootBone;
      b.skins.push(skin); const skinIdx = b.skins.length - 1;
      for (const d of model.draw) {
        const mt = d.material; let mi = matCache.get(model.name + '|' + mt.key);
        if (mi === undefined) {
          const m = { name: mt.name, pbrMetallicRoughness: { metallicFactor: 0, roughnessFactor: 0.75 }, doubleSided: mt.doubleSided };
          if (mt.base) {
            const ti = await texIndex('b|' + mt.base.key + '|' + mt.skin, () => opts.encode(mt.base, mt.skin ? 'jpeg' : 'png'));
            m.pbrMetallicRoughness.baseColorTexture = { index: ti };
          } else if (mt.baseColor) m.pbrMetallicRoughness.baseColorFactor = mt.baseColor;
          if (mt.alphaMode !== 'OPAQUE') { m.alphaMode = mt.alphaMode; if (mt.alphaMode === 'MASK') m.alphaCutoff = 0.4; }
          if (mt.normal && opts.normalMaps !== false) {
            const ti = await texIndex('n|' + mt.normal.key + '|' + (opts.flipNormalY ? 1 : 0), () => opts.encode(G.Convert.normalFromRG(mt.normal, !!opts.flipNormalY), 'png'));
            m.normalTexture = { index: ti };
          }
          b.materials.push(m); mi = b.materials.length - 1; matCache.set(model.name + '|' + mt.key, mi);
        }
        const vc = d.positions.length / 3;
        const prim = {
          attributes: {
            POSITION: b.accessor(d.positions, 5126, 'VEC3', vc, 34962, true),
            NORMAL: b.accessor(d.normals, 5126, 'VEC3', vc, 34962),
            TEXCOORD_0: b.accessor(d.uvs, 5126, 'VEC2', vc, 34962),
            JOINTS_0: b.accessor(d.joints, 5121, 'VEC4', vc, 34962),
            WEIGHTS_0: b.accessor(d.weights, 5121, 'VEC4', vc, 34962, false, true)
          },
          indices: b.accessor(d.indices, 5125, 'SCALAR', d.indices.length, 34963), material: mi
        };
        b.meshes.push({ name: d.name, primitives: [prim] });
        b.nodes.push({ name: d.name, mesh: b.meshes.length - 1, skin: skinIdx }); b.scene.push(b.nodes.length - 1);
      }
    }
    return b.finish();
  }
  G.Glb = { buildGlb };
  if (typeof module !== 'undefined') module.exports = G.Glb;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
