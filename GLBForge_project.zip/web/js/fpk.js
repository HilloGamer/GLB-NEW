/* GLB Forge — pembaca FPK (arsip Fox Engine) */
(function (G) {
  'use strict';
  function readFpk(u8) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const magic = String.fromCharCode(u8[0], u8[1], u8[2], u8[3], u8[4], u8[5]);
    if (magic !== 'foxfpk') throw new Error('Bukan file FPK');
    const n = dv.getUint32(0x20, true), res = [];
    for (let i = 0; i < n + 1; i++) {
      const o = 0x30 + i * 0x30;
      if (o + 0x30 > u8.length) break;
      const off = Number(dv.getBigUint64(o, true)), size = Number(dv.getBigUint64(o + 8, true));
      const no = Number(dv.getBigUint64(o + 16, true)), nl = Number(dv.getBigUint64(o + 24, true));
      if (nl === 0 || nl > 260 || off + size > u8.length || no + nl > u8.length) continue;
      let name = ''; for (let k = 0; k < nl; k++) name += String.fromCharCode(u8[no + k]);
      res.push({ name, data: u8.subarray(off, off + size) });
    }
    return res;
  }
  G.Fpk = { readFpk };
  if (typeof module !== 'undefined') module.exports = G.Fpk;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
