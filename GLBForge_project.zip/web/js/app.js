/* GLB Forge — logika antarmuka */
(function () {
  'use strict';
  const GF = window.GF, $ = id => document.getElementById(id);
  const state = { pkg: null, prepared: [], viewer: null, busy: false };
  window.GFApp = { state };
  const logEl = $('log');
  function log(s) { logEl.textContent += s + '\n'; logEl.scrollTop = logEl.scrollHeight; }
  const tick = () => new Promise(r => setTimeout(r, 20));
  function busy(on, msg) { state.busy = on; const b = $('busy'); b.hidden = !on; if (msg) b.textContent = msg; $('save').disabled = on; }

  async function readFiles(fileList) {
    const files = [];
    for (const f of fileList) {
      const buf = new Uint8Array(await f.arrayBuffer());
      if (/\.zip$/i.test(f.name)) {
        log('Membaca ' + f.name + '…');
        const z = GF.Zip.openZip(buf);
        for (const e of z.entries) {
          if (!/\.(fpk|fmdl|ftex)$/i.test(e.name)) continue;
          files.push({ path: e.name, data: z.read(e) });
        }
      } else files.push({ path: f.name, data: buf });
    }
    return files;
  }

  async function load(fileList) {
    logEl.textContent = '';
    busy(true, 'Membaca file…'); $('viewcard').hidden = false; $('savecard').hidden = true;
    try {
      await tick();
      const files = await readFiles(fileList);
      if (!files.length) throw new Error('Tidak ada file FPK/FMDL/FTEX yang ditemukan');
      const pkg = GF.Convert.openPackage(files, log);
      if (!pkg.models.length) throw new Error('Tidak ada model FMDL di dalam file yang dipilih');
      state.pkg = pkg; state.prepared = [];
      for (const m of pkg.models) {
        busy(true, 'Memproses ' + m.name + '…'); await tick();
        log('Model: ' + m.name);
        const p = GF.Convert.prepareModel(m, pkg.getTexture, log);
        p.draw.forEach(d => log('  mesh ' + d.name + ' (' + d.positions.length / 3 + ' vertex)'));
        if (p.skipped.length) log('  dilewati (tanpa tekstur yang bisa dipakai): ' + p.skipped.join(', '));
        state.prepared.push(p);
      }
      const sel = $('modelSel'); sel.innerHTML = '';
      state.prepared.forEach((p, i) => sel.add(new Option(p.name, String(i))));
      if (state.prepared.length > 1) sel.add(new Option('Gabungan (semua model)', 'all'));
      sel.value = state.prepared.length > 1 ? 'all' : '0';
      if (!state.viewer) state.viewer = new GF.Viewer($('cv'));
      show();
      $('savecard').hidden = false;
      log('Selesai. Putar model di atas, lalu tekan "Simpan hasil".');
    } catch (e) { log('GAGAL: ' + (e && e.message || e)); console.error(e); }
    busy(false);
  }
  function selection() { const v = $('modelSel').value; return v === 'all' ? state.prepared : [state.prepared[+v]]; }
  function show() {
    const sel = selection(); state.viewer.setModels(sel);
    const v = sel.reduce((n, p) => n + p.draw.reduce((a, d) => a + d.positions.length / 3, 0), 0);
    const t = sel.reduce((n, p) => n + p.draw.reduce((a, d) => a + d.indices.length / 3, 0), 0);
    $('summary').textContent = sel.map(p => p.name).join(' + ') + ' — ' + v.toLocaleString('id-ID') + ' vertex, ' + t.toLocaleString('id-ID') + ' segitiga, ' + sel.reduce((n, p) => n + p.bones.length, 0) + ' tulang';
  }

  // ---- simpan ----
  function b64(u8) { let s = ''; for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode.apply(null, u8.subarray(i, i + 0x8000)); return btoa(s); }
  function saveFile(name, bytes) {
    const A = window.AndroidBridge;
    if (A && typeof A.beginSave === 'function' && typeof A.writeChunk === 'function') {
      return new Promise((resolve, reject) => {
        window.__gfSaveReady = ok => {
          if (!ok) return resolve(false);
          (async () => {
            const CH = 3 * 256 * 1024; // kelipatan 3 agar base64 tidak bergeser
            for (let i = 0; i < bytes.length; i += CH) { A.writeChunk(b64(bytes.subarray(i, i + CH))); await tick(); }
            window.__gfSaveDone = ok2 => resolve(!!ok2); A.endSave();
          })().catch(reject);
        };
        A.beginSave(name);
      });
    }
    const url = URL.createObjectURL(new Blob([bytes], { type: 'model/gltf-binary' }));
    const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 10000); return Promise.resolve(true);
  }
  async function save() {
    if (!state.prepared.length || state.busy) return;
    busy(true, 'Membuat GLB…'); $('saveInfo').textContent = '';
    try {
      await tick();
      const sel = selection(), v = $('modelSel').value;
      const glb = await GF.Convert.exportGlb(sel, { normalMaps: $('optNormal').checked, flipNormalY: $('optFlip').checked });
      const name = (v === 'all' ? 'gabungan' : sel[0].name) + '.glb';
      log('GLB dibuat: ' + name + ' (' + (glb.length / 1e6).toFixed(2) + ' MB)');
      state.lastGlb = glb;
      const ok = await saveFile(name, glb);
      $('saveInfo').textContent = ok ? 'Tersimpan: ' + name : 'Penyimpanan dibatalkan.';
    } catch (e) { log('GAGAL menyimpan: ' + (e && e.message || e)); console.error(e); }
    busy(false);
  }

  $('file').addEventListener('change', e => { if (e.target.files.length) load(Array.from(e.target.files)); e.target.value = ''; });
  $('modelSel').addEventListener('change', show);
  $('reset').addEventListener('click', () => state.viewer && state.viewer.resetView());
  $('save').addEventListener('click', save);
})();
