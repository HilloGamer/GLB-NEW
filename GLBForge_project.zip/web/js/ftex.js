/* GLB Forge — pembaca FTEX (tekstur Fox Engine) */
(function (G) {
  'use strict';
  function readFtex(u8) {
    if (u8[0] !== 0x46 || u8[1] !== 0x54 || u8[2] !== 0x45 || u8[3] !== 0x58) throw new Error('Bukan file FTEX');
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const fmt = dv.getUint16(8, true), w = dv.getUint16(10, true), h = dv.getUint16(12, true);
    const mips = u8[0x10];
    let top = null;
    for (let i = 0; i < mips; i++) {
      const o = 0x40 + i * 16;
      const e = { off: dv.getUint32(o, true), usize: dv.getUint32(o + 4, true), csize: dv.getUint32(o + 8, true), idx: u8[o + 12], fn: u8[o + 13], cc: dv.getUint16(o + 14, true) };
      if (e.idx === 0) { top = e; break; }
    }
    if (!top) throw new Error('FTEX tanpa mip utama');
    if (top.fn !== 0) throw new Error('Mip utama ada di file .ftexs (tidak disertakan)');
    const out = new Uint8Array(top.usize); let op = 0;
    for (let c = 0; c < top.cc; c++) {
      const t = top.off + c * 8;
      const cs = dv.getUint16(t, true), us = dv.getUint16(t + 2, true), co = dv.getUint32(t + 4, true);
      const s = top.off + co;
      if (cs === us && u8[s] !== 0x78) { out.set(u8.subarray(s, s + cs), op); op += cs; }
      else { const d = G.Inflate.inflateZlib(u8.subarray(s, s + cs), 0, us); out.set(d.subarray(0, Math.min(d.length, out.length - op)), op); op += d.length; }
    }
    return { format: fmt, width: w, height: h, rgba: G.Bcn.decode(fmt, out, w, h) };
  }
  G.Ftex = { readFtex };
  if (typeof module !== 'undefined') module.exports = G.Ftex;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
