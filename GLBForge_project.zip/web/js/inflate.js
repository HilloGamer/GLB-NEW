/* GLB Forge — inflate (RFC1951) murni JS, tanpa dependensi. Berdasarkan algoritma "tiny inflate". */
(function (G) {
  'use strict';
  const LBITS = [0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0];
  const LBASE = [3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258];
  const DBITS = [0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13];
  const DBASE = [1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577];
  const CLC = [16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];

  function Tree() { this.t = new Uint16Array(16); this.s = new Uint16Array(288); }
  function build(tree, lens, off, num) {
    const t = tree.t, offs = new Uint16Array(16);
    t.fill(0);
    for (let i = 0; i < num; i++) t[lens[off + i]]++;
    t[0] = 0;
    let sum = 0;
    for (let i = 0; i < 16; i++) { offs[i] = sum; sum += t[i]; }
    for (let i = 0; i < num; i++) if (lens[off + i]) tree.s[offs[lens[off + i]]++] = i;
  }
  let FLT = null, FDT = null;
  function fixed() {
    if (FLT) return;
    FLT = new Tree(); FDT = new Tree();
    const l = new Uint8Array(288);
    for (let i = 0; i < 144; i++) l[i] = 8;
    for (let i = 144; i < 256; i++) l[i] = 9;
    for (let i = 256; i < 280; i++) l[i] = 7;
    for (let i = 280; i < 288; i++) l[i] = 8;
    build(FLT, l, 0, 288);
    const d = new Uint8Array(30).fill(5);
    build(FDT, d, 0, 30);
  }

  /** Inflate data DEFLATE mentah mulai dari `start`. sizeHint = ukuran keluaran (jika diketahui). */
  function inflateRaw(src, start, sizeHint) {
    fixed();
    let pos = start || 0, tag = 0, bc = 0;
    let out = new Uint8Array(sizeHint || Math.max(1024, src.length * 3)), op = 0;
    const lt = new Tree(), dt = new Tree();
    function bit() { if (!bc--) { tag = src[pos++]; bc = 7; } const b = tag & 1; tag >>>= 1; return b; }
    function bits(n, base) { let v = 0; for (let i = 0; i < n; i++) v |= bit() << i; return v + base; }
    function sym(tree) {
      const t = tree.t; let sum = 0, cur = 0, len = 0;
      do { cur = 2 * cur + bit(); len++; sum += t[len]; cur -= t[len]; } while (cur >= 0 && len < 16);
      if (len >= 16 && cur >= 0) throw new Error('inflate: kode Huffman rusak');
      return tree.s[sum + cur];
    }
    function grow(need) {
      if (op + need <= out.length) return;
      let n = out.length * 2; while (n < op + need) n *= 2;
      const o = new Uint8Array(n); o.set(out.subarray(0, op)); out = o;
    }
    function dynTrees() {
      const hlit = bits(5, 257), hdist = bits(5, 1), hclen = bits(4, 4);
      const lens = new Uint8Array(320); const clt = new Tree();
      for (let i = 0; i < hclen; i++) lens[CLC[i]] = bits(3, 0);
      build(clt, lens, 0, 19);
      lens.fill(0);
      let num = 0;
      while (num < hlit + hdist) {
        const s = sym(clt); let prev, rep;
        switch (s) {
          case 16: prev = lens[num - 1]; rep = bits(2, 3); while (rep--) lens[num++] = prev; break;
          case 17: rep = bits(3, 3); while (rep--) lens[num++] = 0; break;
          case 18: rep = bits(7, 11); while (rep--) lens[num++] = 0; break;
          default: lens[num++] = s;
        }
      }
      build(lt, lens, 0, hlit); build(dt, lens, hlit, hdist);
    }
    function block(l, d) {
      for (;;) {
        let s = sym(l);
        if (s === 256) return;
        if (s < 256) { grow(1); out[op++] = s; }
        else {
          s -= 257;
          const len = bits(LBITS[s], LBASE[s]);
          const ds = sym(d), dist = bits(DBITS[ds], DBASE[ds]);
          if (dist > op) throw new Error('inflate: jarak tidak valid');
          grow(len);
          for (let i = 0; i < len; i++) { out[op] = out[op - dist]; op++; }
        }
      }
    }
    let fin;
    do {
      fin = bit();
      const type = bits(2, 0);
      if (type === 0) {
        bc = 0;
        const len = src[pos] | (src[pos + 1] << 8); pos += 4;
        grow(len); out.set(src.subarray(pos, pos + len), op); op += len; pos += len;
      } else if (type === 1) block(FLT, FDT);
      else if (type === 2) { dynTrees(); block(lt, dt); }
      else throw new Error('inflate: tipe blok tidak valid');
    } while (!fin);
    return out.subarray(0, op);
  }
  /** Inflate data zlib (header 2 byte). */
  function inflateZlib(src, start, sizeHint) { return inflateRaw(src, (start || 0) + 2, sizeHint); }

  G.Inflate = { inflateRaw, inflateZlib };
  if (typeof module !== 'undefined') module.exports = G.Inflate;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
