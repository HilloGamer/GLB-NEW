/* GLB Forge — orkestrasi: baca paket, siapkan model, ekspor GLB */
(function (G) {
  'use strict';
  const baseName = p => p.split(/[\\/]/).pop();
  const stem = p => baseName(p).replace(/\.[^.]*$/, '').toLowerCase();

  /** files: [{path, data:Uint8Array}] -> {models:[{id,name,fmdl}], findTexture(file)} */
  function openPackage(files, log) {
    log = log || (() => {});
    const out = [], ftex = [];
    for (const f of files) {
      const l = f.path.toLowerCase();
      if (l.endsWith('.ftex')) ftex.push(f);
      else if (l.endsWith('.fpk')) {
        let items; try { items = G.Fpk.readFpk(f.data); } catch (e) { log('FPK gagal dibaca: ' + f.path + ' (' + e.message + ')'); continue; }
        for (const it of items) if (it.name.toLowerCase().endsWith('.fmdl')) out.push({ name: it.name, source: f.path, data: it.data });
      } else if (l.endsWith('.fmdl')) out.push({ name: baseName(f.path), source: f.path, data: f.data });
    }
    const texCache = new Map();
    function findKey(file) {
      const s = stem(file);
      const c = ftex.filter(t => stem(t.path) === s);
      if (!c.length) return null;
      c.sort((a, b) => ((a.path.toLowerCase().includes('#windx11') ? 0 : 1) - (b.path.toLowerCase().includes('#windx11') ? 0 : 1)) || a.path.length - b.path.length);
      return c[0];
    }
    function getTexture(file) {
      const t = findKey(file); if (!t) return null;
      if (!texCache.has(t.path)) {
        let r = null;
        try { const d = G.Ftex.readFtex(t.data); r = { key: t.path, w: d.width, h: d.height, rgba: d.rgba, name: baseName(t.path) }; }
        catch (e) { log('Tekstur gagal didecode: ' + baseName(t.path) + ' (' + e.message + ')'); }
        texCache.set(t.path, r);
      }
      return texCache.get(t.path);
    }
    const models = out.map((m, i) => {
      const fmdl = G.Fmdl.parseFmdl(m.data);
      return { id: i, name: m.name.replace(/\.fmdl$/i, ''), source: m.source, fmdl };
    });
    return { models, getTexture, textureCount: ftex.length };
  }

  /** Susun data siap-gambar & siap-ekspor dari hasil parse FMDL. */
  function prepareModel(model, getTexture, log) {
    log = log || (() => {});
    const f = model.fmdl, draw = [], skipped = [], matCache = new Map();
    function material(inst) {
      if (matCache.has(inst.name)) return matCache.get(inst.name);
      const sh = inst.shader.toLowerCase(), skin = sh.includes('skin'), occl = sh.includes('eyeocclusion');
      let baseF = null, nrmF = null;
      for (const t of inst.textures) {
        if (t.slot === 'Base_Tex_SRGB' && !baseF) baseF = t.file;
        if (t.slot === 'NormalMap_Tex_NRM' && !nrmF) nrmF = t.file;
      }
      if (!baseF) { const t = inst.textures.find(x => /_srgb$/i.test(x.slot)); if (t) baseF = t.file; }
      const base = baseF ? getTexture(baseF) : null;
      let res;
      if (!base && !skin && !occl) res = null;
      else {
        res = { key: inst.name + '|' + inst.shader, name: inst.name, skin, base,
          normal: nrmF ? getTexture(nrmF) : null, doubleSided: !skin,
          alphaMode: occl ? 'BLEND' : (skin ? 'OPAQUE' : 'MASK'), baseColor: (!base && occl) ? [0, 0, 0, 1] : (!base ? [0.8, 0.65, 0.55, 1] : null) };
      }
      matCache.set(inst.name, res); return res;
    }
    f.meshes.forEach((m, mi) => {
      const inst = f.instances[m.mat], mt = material(inst), nm = inst.name + '_' + mi;
      if (!mt) { skipped.push(nm); return; }
      const A = m.attr, vc = m.vc;
      if (!A[0] || !A[2] || !A[8]) { skipped.push(nm + ' (atribut tidak lengkap)'); return; }
      const positions = new Float32Array(vc * 3), normals = new Float32Array(vc * 3), uvs = new Float32Array(vc * 2);
      for (let i = 0; i < vc; i++) {
        positions.set(A[0].data.subarray(i * 3, i * 3 + 3), i * 3);
        normals.set(A[2].data.subarray(i * A[2].n, i * A[2].n + 3), i * 3);
        uvs.set(A[8].data.subarray(i * 2, i * 2 + 2), i * 2);
      }
      const grp = f.bonegroups[m.bgroup] || [0];
      const joints = new Uint8Array(vc * 4), weights = new Uint8Array(vc * 4);
      if (A[7] && A[1]) for (let i = 0; i < vc * 4; i++) {
        joints[i] = grp[Math.min(A[7].data[i], grp.length - 1)] & 255;
        weights[i] = Math.round(A[1].data[i] * 255);
      } else for (let i = 0; i < vc; i++) weights[i * 4] = 255;
      for (let i = 0; i < vc; i++) { // bobot harus berjumlah tepat 255 (aturan glTF)
        let sum = 0, big = 0; for (let k = 0; k < 4; k++) { sum += weights[i * 4 + k]; if (weights[i * 4 + k] > weights[i * 4 + big]) big = k; }
        if (sum !== 255) weights[i * 4 + big] += 255 - sum;
      }
      const ix = new Uint32Array(m.indices.length);
      for (let k = 0; k + 2 < ix.length; k += 3) { ix[k] = m.indices[k]; ix[k + 1] = m.indices[k + 2]; ix[k + 2] = m.indices[k + 1]; } // CW (D3D) -> CCW (glTF)
      draw.push({ name: nm, positions, normals, uvs, joints, weights, indices: ix, material: mt });
    });
    return { name: model.name, bones: f.bones, draw, skipped };
  }

  /** Normal map Fox (R,G = X,Y) -> RGB tangent-space standar glTF. */
  function normalFromRG(tex, flipY) {
    const n = tex.w * tex.h, out = new Uint8Array(n * 3), s = tex.rgba;
    for (let i = 0; i < n; i++) {
      const x = s[i * 4] / 127.5 - 1; let y = s[i * 4 + 1] / 127.5 - 1; if (flipY) y = -y;
      const z = Math.sqrt(Math.max(0, 1 - x * x - y * y));
      out[i * 3] = Math.round((x * 0.5 + 0.5) * 255); out[i * 3 + 1] = Math.round((y * 0.5 + 0.5) * 255); out[i * 3 + 2] = Math.round((z * 0.5 + 0.5) * 255);
    }
    return { key: tex.key + '#n', w: tex.w, h: tex.h, rgb: out };
  }

  /** Encoder default: PNG (kanal RGB/RGBA), JPEG bila canvas tersedia. */
  async function defaultEncode(tex, kind) {
    const has = typeof document !== 'undefined' && document.createElement;
    if (kind === 'jpeg' && has && tex.rgba) {
      const c = document.createElement('canvas'); c.width = tex.w; c.height = tex.h;
      const ctx = c.getContext('2d'); const px = new Uint8ClampedArray(tex.w * tex.h * 4);
      for (let i = 0; i < tex.w * tex.h; i++) { px[i * 4] = tex.rgba[i * 4]; px[i * 4 + 1] = tex.rgba[i * 4 + 1]; px[i * 4 + 2] = tex.rgba[i * 4 + 2]; px[i * 4 + 3] = 255; }
      ctx.putImageData(new ImageData(px, tex.w, tex.h), 0, 0);
      const blob = await new Promise(r => c.toBlob(r, 'image/jpeg', 0.92));
      if (blob) return { bytes: new Uint8Array(await blob.arrayBuffer()), mime: 'image/jpeg' };
    }
    if (tex.rgb) return { bytes: await G.Png.encodePng(tex.rgb, tex.w, tex.h, 3), mime: 'image/png' };
    return { bytes: await G.Png.encodePng(tex.rgba, tex.w, tex.h, 4), mime: 'image/png' };
  }

  async function exportGlb(prepared, opts) {
    opts = Object.assign({ encode: defaultEncode, flipNormalY: false, normalMaps: true }, opts || {});
    return G.Glb.buildGlb(prepared, opts);
  }
  G.Convert = { openPackage, prepareModel, exportGlb, normalFromRG, defaultEncode };
  if (typeof module !== 'undefined') module.exports = G.Convert;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
