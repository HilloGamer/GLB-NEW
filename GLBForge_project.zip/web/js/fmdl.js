/* GLB Forge — pembaca FMDL (model Fox Engine, PES) */
(function (G) {
  'use strict';
  function half(h) {
    const s = (h & 0x8000) ? -1 : 1, e = (h >> 10) & 31, f = h & 1023;
    if (e === 0) return s * Math.pow(2, -14) * (f / 1024);
    if (e === 31) return f ? NaN : s * Infinity;
    return s * Math.pow(2, e - 15) * (1 + f / 1024);
  }
  function parseFmdl(u8) {
    if (String.fromCharCode(u8[0], u8[1], u8[2], u8[3]) !== 'FMDL') throw new Error('Bukan file FMDL');
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    const U16 = o => dv.getUint16(o, true), I16 = o => dv.getInt16(o, true), U32 = o => dv.getUint32(o, true), F32 = o => dv.getFloat32(o, true);
    const n0 = U32(0x20), n1 = U32(0x24), s0 = U32(0x28), s1 = U32(0x30);
    const sec0 = {}, sec1 = {};
    for (let i = 0; i < n0; i++) { const o = 0x40 + i * 8; sec0[U16(o)] = { c: U16(o + 2), o: s0 + U32(o + 4) }; }
    for (let i = 0; i < n1; i++) { const o = 0xd8 + i * 12; sec1[U32(o)] = { o: s1 + U32(o + 4), l: U32(o + 8) }; }
    const need = (t, n) => { if (!sec0[t]) throw new Error('FMDL: bagian ' + n + ' tidak ditemukan'); return sec0[t]; };
    // string
    const si = need(12, 'string'), sb = sec1[3].o, S = [];
    for (let i = 0; i < si.c; i++) {
      const o = si.o + i * 8, l = U16(o + 2), off = U32(o + 4); let s = '';
      for (let k = 0; k < l; k++) s += String.fromCharCode(u8[sb + off + k]);
      S.push(s);
    }
    // tulang
    const bones = [], bs = need(0, 'tulang');
    for (let i = 0; i < bs.c; i++) {
      const o = bs.o + i * 0x30;
      bones.push({ name: S[U16(o)], parent: I16(o + 2), world: [F32(o + 0x20), F32(o + 0x24), F32(o + 0x28)] });
    }
    // grup tulang
    const bgroups = [];
    if (sec0[5]) for (let i = 0; i < sec0[5].c; i++) {
      const o = sec0[5].o + i * 68, cnt = U16(o + 2), g = [];
      for (let k = 0; k < cnt; k++) g.push(U16(o + 4 + k * 2));
      bgroups.push(g);
    }
    // material
    const tex = [], par = [], mats = [], insts = [], vecs = [];
    for (let i = 0; i < (sec0[6] ? sec0[6].c : 0); i++) { const o = sec0[6].o + i * 4; tex.push([U16(o), U16(o + 2)]); }
    for (let i = 0; i < (sec0[7] ? sec0[7].c : 0); i++) { const o = sec0[7].o + i * 4; par.push([U16(o), U16(o + 2)]); }
    for (let i = 0; i < (sec0[8] ? sec0[8].c : 0); i++) { const o = sec0[8].o + i * 4; mats.push([U16(o), U16(o + 2)]); }
    if (sec1[0]) for (let i = 0; i < sec1[0].l / 16; i++) { const o = sec1[0].o + i * 16; vecs.push([F32(o), F32(o + 4), F32(o + 8), F32(o + 12)]); }
    for (let i = 0; i < (sec0[4] ? sec0[4].c : 0); i++) {
      const o = sec0[4].o + i * 16, nm = U16(o), mid = U16(o + 4), tc = u8[o + 6], pc = u8[o + 7], ft = U16(o + 8), fp = U16(o + 10);
      const textures = [], params = [];
      for (let k = 0; k < tc; k++) { const [pn, ref] = par[ft + k]; const [fn, pth] = tex[ref]; textures.push({ slot: S[pn], file: S[fn], path: S[pth] }); }
      for (let k = 0; k < pc; k++) { const [pn, ref] = par[fp + k]; params.push({ name: S[pn], value: vecs[ref] }); }
      insts.push({ name: S[nm], material: S[mats[mid][0]], shader: S[mats[mid][1]], textures, params });
    }
    // buffer
    const bo = [], ve = [], mf = [], lod = [];
    for (let i = 0; i < sec0[10].c; i++) { const o = sec0[10].o + i * 8; bo.push({ a: u8[o], b: u8[o + 1], stride: u8[o + 2], c: u8[o + 3], off: U32(o + 4) }); }
    for (let i = 0; i < sec0[11].c; i++) { const o = sec0[11].o + i * 4; ve.push({ use: u8[o], type: u8[o + 1], off: U16(o + 2) }); }
    for (let i = 0; i < sec0[9].c; i++) { const o = sec0[9].o + i * 8; mf.push({ nb: u8[o], nv: u8[o + 1], fb: U16(o + 4), fv: U16(o + 6) }); }
    for (let i = 0; i < sec0[14].c; i++) { const o = sec0[14].o + i * 16; lod.push({ type: U32(o), len: U32(o + 4), off: U32(o + 8) }); }
    const base = sec1[2].o, facesBase = base + lod[2].off;
    const SZ = { 1: [4, 3], 2: [4, 2], 3: [4, 4], 6: [2, 4], 7: [2, 2], 8: [1, 4], 9: [1, 4] };
    const meshes = [], ms = need(3, 'mesh');
    for (let mi = 0; mi < ms.c; mi++) {
      const o = ms.o + mi * 0x30;
      const mesh = { alpha: u8[o], shadow: u8[o + 1], mat: U16(o + 4), fmt: U16(o + 6), vc: U16(o + 10), ffirst: U32(o + 0x10), fcount: U32(o + 0x14), bgroup: U32(o + 0x18) };
      const f = mf[mesh.fmt], bufs = bo.slice(f.fb, f.fb + f.nb), els = ve.slice(f.fv, f.fv + f.nv), vc = mesh.vc;
      const A = {};
      for (const e of els) {
        const sz = SZ[e.type]; if (!sz) continue;
        let b;
        if (e.use === 0) b = bufs.find(x => x.a === 0) || bufs[0];
        else b = bufs.find(x => x.a === 1 && x.stride >= e.off + sz[0] * sz[1]) || bufs[1];
        const start = base + lod[b.a].off + b.off, st = b.stride, n = sz[1];
        const arr = new Float32Array(vc * n);
        for (let v = 0; v < vc; v++) for (let k = 0; k < n; k++) {
          const p = start + v * st + e.off + k * sz[0];
          let x;
          switch (e.type) {
            case 1: case 2: case 3: x = dv.getFloat32(p, true); break;
            case 6: case 7: x = half(dv.getUint16(p, true)); break;
            case 8: x = u8[p] / 255; break;
            default: x = u8[p];
          }
          arr[v * n + k] = x;
        }
        A[e.use] = { n, data: arr };
      }
      mesh.attr = A;
      const ix = new Uint32Array(mesh.fcount);
      for (let k = 0; k < mesh.fcount; k++) ix[k] = dv.getUint16(facesBase + (mesh.ffirst + k) * 2, true);
      mesh.indices = ix;
      meshes.push(mesh);
    }
    return { strings: S, bones, bonegroups: bgroups, instances: insts, meshes };
  }
  G.Fmdl = { parseFmdl };
  if (typeof module !== 'undefined') module.exports = G.Fmdl;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
