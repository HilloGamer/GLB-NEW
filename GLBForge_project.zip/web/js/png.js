/* GLB Forge — encoder PNG (zlib lewat CompressionStream) */
(function (G) {
  'use strict';
  let CRC = null;
  function crc32(u8) {
    if (!CRC) { CRC = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; CRC[n] = c >>> 0; } }
    let c = 0xFFFFFFFF; for (let i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0;
  }
  async function deflate(u8) {
    const cs = new CompressionStream('deflate');
    const w = cs.writable.getWriter(); w.write(u8); w.close();
    const buf = await new Response(cs.readable).arrayBuffer();
    return new Uint8Array(buf);
  }
  function chunk(type, data) {
    const out = new Uint8Array(12 + data.length), dv = new DataView(out.buffer);
    dv.setUint32(0, data.length); for (let i = 0; i < 4; i++) out[4 + i] = type.charCodeAt(i);
    out.set(data, 8); dv.setUint32(8 + data.length, crc32(out.subarray(4, 8 + data.length))); return out;
  }
  /** rgba: Uint8Array w*h*4 (atau rgb jika channels=3). Mengembalikan PNG bytes. */
  async function encodePng(pix, w, h, channels) {
    const ch = channels || 4, bpp = ch, rl = w * ch;
    const raw = new Uint8Array((rl + 1) * h);
    const cand = [new Uint8Array(rl), new Uint8Array(rl), new Uint8Array(rl)];
    for (let y = 0; y < h; y++) {
      const row = pix.subarray(y * rl, (y + 1) * rl), prev = y ? pix.subarray((y - 1) * rl, y * rl) : null;
      const sub = cand[0], up = cand[1], pa = cand[2];
      let ss = 0, su = 0, sp = 0;
      for (let i = 0; i < rl; i++) {
        const a = i >= bpp ? row[i - bpp] : 0, b = prev ? prev[i] : 0, c = (i >= bpp && prev) ? prev[i - bpp] : 0;
        const x = row[i];
        const vs = (x - a) & 255, vu = (x - b) & 255;
        const p = a + b - c, pa_ = Math.abs(p - a), pb = Math.abs(p - b), pc = Math.abs(p - c);
        const pr = (pa_ <= pb && pa_ <= pc) ? a : (pb <= pc ? b : c);
        const vp = (x - pr) & 255;
        sub[i] = vs; up[i] = vu; pa[i] = vp;
        ss += vs < 128 ? vs : 256 - vs; su += vu < 128 ? vu : 256 - vu; sp += vp < 128 ? vp : 256 - vp;
      }
      const o = y * (rl + 1);
      if (sp <= ss && sp <= su) { raw[o] = 4; raw.set(pa, o + 1); }
      else if (su <= ss) { raw[o] = 2; raw.set(up, o + 1); }
      else { raw[o] = 1; raw.set(sub, o + 1); }
    }
    const z = await deflate(raw);
    const hd = new Uint8Array(13), dv = new DataView(hd.buffer);
    dv.setUint32(0, w); dv.setUint32(4, h); hd[8] = 8; hd[9] = ch === 4 ? 6 : 2;
    const sig = Uint8Array.of(137, 80, 78, 71, 13, 10, 26, 10);
    const parts = [sig, chunk('IHDR', hd), chunk('IDAT', z), chunk('IEND', new Uint8Array(0))];
    const out = new Uint8Array(parts.reduce((s, p) => s + p.length, 0)); let o = 0;
    for (const p of parts) { out.set(p, o); o += p.length; }
    return out;
  }
  G.Png = { encodePng, crc32 };
  if (typeof module !== 'undefined') module.exports = G.Png;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
