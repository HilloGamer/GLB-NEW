/* GLB Forge — pembaca ZIP (store + deflate). */
(function (G) {
  'use strict';
  function u16(b, o) { return b[o] | (b[o + 1] << 8); }
  function u32(b, o) { return (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0; }
  function decodeName(bytes, utf8) {
    try { return new TextDecoder(utf8 ? 'utf-8' : 'latin1').decode(bytes); }
    catch (e) { let s = ''; for (const c of bytes) s += String.fromCharCode(c); return s; }
  }
  function openZip(buf) {
    const b = buf instanceof Uint8Array ? buf : new Uint8Array(buf);
    let e = -1;
    for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) {
      if (b[i] === 0x50 && b[i + 1] === 0x4b && b[i + 2] === 5 && b[i + 3] === 6) { e = i; break; }
    }
    if (e < 0) throw new Error('Bukan file ZIP yang valid');
    const n = u16(b, e + 10); let p = u32(b, e + 16);
    const entries = [];
    for (let i = 0; i < n; i++) {
      if (u32(b, p) !== 0x02014b50) throw new Error('Direktori ZIP rusak');
      const flag = u16(b, p + 8), method = u16(b, p + 10);
      const csize = u32(b, p + 20), usize = u32(b, p + 24);
      const nl = u16(b, p + 28), el = u16(b, p + 30), cl = u16(b, p + 32), lo = u32(b, p + 42);
      const name = decodeName(b.subarray(p + 46, p + 46 + nl), !!(flag & 0x800));
      entries.push({ name, method, csize, usize, lo });
      p += 46 + nl + el + cl;
    }
    function read(ent) {
      const o = ent.lo;
      if (u32(b, o) !== 0x04034b50) throw new Error('Header lokal ZIP rusak: ' + ent.name);
      const start = o + 30 + u16(b, o + 26) + u16(b, o + 28);
      if (ent.method === 0) return b.subarray(start, start + ent.usize);
      if (ent.method === 8) return G.Inflate.inflateRaw(b.subarray(start, start + ent.csize), 0, ent.usize);
      throw new Error('Metode kompresi ZIP tidak didukung: ' + ent.method);
    }
    return { entries: entries.filter(x => !x.name.endsWith('/')), read };
  }
  G.Zip = { openZip };
  if (typeof module !== 'undefined') module.exports = G.Zip;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
