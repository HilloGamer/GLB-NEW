/* GLB Forge — viewer WebGL mandiri (tanpa library) */
(function (G) {
  'use strict';
  const VS = `#version 300 es
layout(location=0) in vec3 aPos; layout(location=1) in vec3 aNor; layout(location=2) in vec2 aUv;
uniform mat4 uMVP; uniform mat3 uNrm;
out vec3 vN; out vec2 vUv;
void main(){ vN = normalize(uNrm * aNor); vUv = aUv; gl_Position = uMVP * vec4(aPos, 1.0); }`;
  const FS = `#version 300 es
precision highp float;
in vec3 vN; in vec2 vUv; out vec4 o;
uniform sampler2D uTex; uniform float uHasTex; uniform vec4 uColor; uniform float uCut; uniform float uBlend; uniform float uDouble;
void main(){
  vec4 c = uHasTex > 0.5 ? texture(uTex, vUv) : uColor;
  if (uBlend < 0.5 && uCut > 0.0 && c.a < uCut) discard;
  vec3 n = normalize(vN); if (uDouble > 0.5 && !gl_FrontFacing) n = -n;
  vec3 L = normalize(vec3(0.35, 0.55, 0.75));
  float d = max(dot(n, L), 0.0), h = 0.5 + 0.5 * n.y;
  vec3 albedo = pow(c.rgb, vec3(2.2));
  vec3 col = albedo * (vec3(0.75, 0.76, 0.82) * (0.4 + 0.6 * h) + vec3(1.0, 0.97, 0.92) * d * 0.85);
  o = vec4(pow(col, vec3(1.0 / 2.2)), uBlend > 0.5 ? c.a : 1.0);
}`;
  function m4mul(a, b) { const o = new Float32Array(16); for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) { let s = 0; for (let k = 0; k < 4; k++) s += a[k * 4 + j] * b[i * 4 + k]; o[i * 4 + j] = s; } return o; }
  function persp(f, a, n, fa) { const t = 1 / Math.tan(f / 2), m = new Float32Array(16); m[0] = t / a; m[5] = t; m[10] = (fa + n) / (n - fa); m[11] = -1; m[14] = 2 * fa * n / (n - fa); return m; }

  class Viewer {
    constructor(canvas) {
      this.c = canvas;
      const gl = canvas.getContext('webgl2', { antialias: true, alpha: true, premultipliedAlpha: false });
      if (!gl) throw new Error('WebGL2 tidak tersedia di perangkat ini');
      this.gl = gl; this.items = []; this.texCache = new Map();
      this.yaw = 0.35; this.pitch = 0.08; this.dist = 1; this.target = [0, 0, 0]; this.radius = 1;
      this.prog = this._program(VS, FS);
      this.u = {}; for (const n of ['uMVP', 'uNrm', 'uTex', 'uHasTex', 'uColor', 'uCut', 'uBlend', 'uDouble']) this.u[n] = gl.getUniformLocation(this.prog, n);
      this._input(); this._raf = null; this.dirty = true;
      new ResizeObserver(() => { this.dirty = true; }).observe(canvas);
      const loop = () => { if (this.dirty) { this.render(); this.dirty = false; } this._raf = requestAnimationFrame(loop); }; loop();
    }
    _program(vs, fs) {
      const gl = this.gl, mk = (t, s) => { const x = gl.createShader(t); gl.shaderSource(x, s); gl.compileShader(x); if (!gl.getShaderParameter(x, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(x)); return x; };
      const p = gl.createProgram(); gl.attachShader(p, mk(gl.VERTEX_SHADER, vs)); gl.attachShader(p, mk(gl.FRAGMENT_SHADER, fs)); gl.linkProgram(p);
      if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p)); return p;
    }
    _tex(t) {
      if (!t) return null; const gl = this.gl;
      if (this.texCache.has(t.key)) return this.texCache.get(t.key);
      const tx = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, tx);
      gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, t.w, t.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, t.rgba);
      gl.generateMipmap(gl.TEXTURE_2D);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
      const ext = gl.getExtension('EXT_texture_filter_anisotropic'); if (ext) gl.texParameterf(gl.TEXTURE_2D, ext.TEXTURE_MAX_ANISOTROPY_EXT, 4);
      this.texCache.set(t.key, tx); return tx;
    }
    /** prepared: array hasil Convert.prepareModel */
    setModels(prepared) {
      const gl = this.gl;
      for (const it of this.items) { gl.deleteVertexArray(it.vao); gl.deleteBuffer(it.b1); gl.deleteBuffer(it.b2); gl.deleteBuffer(it.b3); gl.deleteBuffer(it.bi); }
      this.items = [];
      const mn = [1e9, 1e9, 1e9], mx = [-1e9, -1e9, -1e9];
      for (const m of prepared) for (const d of m.draw) {
        const vao = gl.createVertexArray(); gl.bindVertexArray(vao);
        const mkb = (data, loc, n) => { const b = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, b); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, n, gl.FLOAT, false, 0, 0); return b; };
        const b1 = mkb(d.positions, 0, 3), b2 = mkb(d.normals, 1, 3), b3 = mkb(d.uvs, 2, 2);
        const bi = gl.createBuffer(); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, bi); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, d.indices, gl.STATIC_DRAW);
        gl.bindVertexArray(null);
        for (let i = 0; i < d.positions.length; i += 3) for (let k = 0; k < 3; k++) { const v = d.positions[i + k]; if (v < mn[k]) mn[k] = v; if (v > mx[k]) mx[k] = v; }
        this.items.push({ vao, b1, b2, b3, bi, n: d.indices.length, mat: d.material, tex: this._tex(d.material.base) });
      }
      if (this.items.length) {
        this.target = [(mn[0] + mx[0]) / 2, (mn[1] + mx[1]) / 2, (mn[2] + mx[2]) / 2];
        this.radius = Math.max(0.05, Math.hypot(mx[0] - mn[0], mx[1] - mn[1], mx[2] - mn[2]) / 2);
        this.dist = this.radius * 2.4;
      }
      this.dirty = true;
    }
    resetView() { this.yaw = 0.35; this.pitch = 0.08; this.dist = this.radius * 2.4; this.dirty = true; }
    render() {
      const gl = this.gl, c = this.c, dpr = Math.min(window.devicePixelRatio || 1, 2);
      const w = Math.max(1, Math.round(c.clientWidth * dpr)), h = Math.max(1, Math.round(c.clientHeight * dpr));
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
      gl.viewport(0, 0, w, h); gl.clearColor(0.15, 0.155, 0.19, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
      if (!this.items.length) return;
      const cy = Math.cos(this.yaw), sy = Math.sin(this.yaw), cp = Math.cos(this.pitch), sp = Math.sin(this.pitch);
      const eye = [this.target[0] + this.dist * cp * sy, this.target[1] + this.dist * sp, this.target[2] + this.dist * cp * cy];
      let f = [this.target[0] - eye[0], this.target[1] - eye[1], this.target[2] - eye[2]]; const fl = Math.hypot(...f); f = f.map(x => x / fl);
      let s = [f[1] * 0 - f[2] * 1, f[2] * 0 - f[0] * 0, f[0] * 1 - f[1] * 0]; // f x up(0,1,0)
      s = [-f[2], 0, f[0]]; const sl = Math.hypot(...s); s = s.map(x => x / sl);
      const u = [s[1] * f[2] - s[2] * f[1], s[2] * f[0] - s[0] * f[2], s[0] * f[1] - s[1] * f[0]];
      const V = new Float32Array([s[0], u[0], -f[0], 0, s[1], u[1], -f[1], 0, s[2], u[2], -f[2], 0, -(s[0] * eye[0] + s[1] * eye[1] + s[2] * eye[2]), -(u[0] * eye[0] + u[1] * eye[1] + u[2] * eye[2]), f[0] * eye[0] + f[1] * eye[1] + f[2] * eye[2], 1]);
      const P = persp(0.8, w / h, Math.max(0.01, this.dist - this.radius * 3), this.dist + this.radius * 3);
      const MVP = m4mul(P, V);
      gl.useProgram(this.prog); gl.uniformMatrix4fv(this.u.uMVP, false, MVP);
      gl.uniformMatrix3fv(this.u.uNrm, false, new Float32Array([1, 0, 0, 0, 1, 0, 0, 0, 1]));
      gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK); gl.depthMask(true); gl.disable(gl.BLEND);
      const pass = blend => {
        for (const it of this.items) {
          const isBlend = it.mat.alphaMode === 'BLEND'; if (isBlend !== blend) continue;
          if (blend) { gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); } else { gl.disable(gl.BLEND); gl.depthMask(true); }
          if (it.mat.doubleSided) gl.disable(gl.CULL_FACE); else gl.enable(gl.CULL_FACE);
          gl.uniform1f(this.u.uHasTex, it.tex ? 1 : 0); gl.uniform1f(this.u.uBlend, isBlend ? 1 : 0); gl.uniform1f(this.u.uDouble, it.mat.doubleSided ? 1 : 0);
          gl.uniform1f(this.u.uCut, it.mat.alphaMode === 'MASK' ? 0.4 : 0);
          const col = it.mat.baseColor || [0.8, 0.8, 0.8, 1]; gl.uniform4fv(this.u.uColor, col);
          if (it.tex) { gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, it.tex); gl.uniform1i(this.u.uTex, 0); }
          gl.bindVertexArray(it.vao); gl.drawElements(gl.TRIANGLES, it.n, gl.UNSIGNED_INT, 0);
        }
      };
      pass(false); pass(true); gl.depthMask(true); gl.bindVertexArray(null);
    }
    _input() {
      const c = this.c, ptr = new Map(); let lastD = 0, lastMid = null;
      c.style.touchAction = 'none';
      c.addEventListener('pointerdown', e => { c.setPointerCapture(e.pointerId); ptr.set(e.pointerId, [e.clientX, e.clientY]); lastD = 0; lastMid = null; });
      const up = e => { ptr.delete(e.pointerId); lastD = 0; lastMid = null; };
      c.addEventListener('pointerup', up); c.addEventListener('pointercancel', up);
      c.addEventListener('pointermove', e => {
        if (!ptr.has(e.pointerId)) return;
        const p = ptr.get(e.pointerId), dx = e.clientX - p[0], dy = e.clientY - p[1]; ptr.set(e.pointerId, [e.clientX, e.clientY]);
        if (ptr.size === 1) { this.yaw -= dx * 0.008; this.pitch = Math.max(-1.45, Math.min(1.45, this.pitch + dy * 0.008)); }
        else if (ptr.size === 2) {
          const [a, b] = [...ptr.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]);
          if (lastD) this.dist = Math.max(this.radius * 0.4, Math.min(this.radius * 12, this.dist * lastD / d));
          lastD = d;
        }
        this.dirty = true;
      });
      c.addEventListener('wheel', e => { e.preventDefault(); this.dist = Math.max(this.radius * 0.4, Math.min(this.radius * 12, this.dist * (e.deltaY > 0 ? 1.1 : 0.9))); this.dirty = true; }, { passive: false });
    }
  }
  G.Viewer = Viewer;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
