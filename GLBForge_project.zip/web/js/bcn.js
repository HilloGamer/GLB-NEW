/* GLB Forge — decoder tekstur BC1 (DXT1), BC3 (DXT5), BC7. Menghasilkan RGBA8. */
(function (G) {
  'use strict';
  // Tabel partisi BC7 (dihasilkan & diverifikasi terhadap decoder referensi)
  const T2 = ["0011001100110011", "0001000100010001", "0111011101110111", "0001001100110111", "0000000100010011", "0011011101111111", "0001001101111111", "0000000100110111", "0000000000010011", "0011011111111111", "0000000101111111", "0000000000010111", "0001011111111111", "0000000011111111", "0000111111111111", "0000000000001111", "0000100011101111", "0111000100000000", "0000000010001110", "0111001100010000", "0011000100000000", "0000100011001110", "0000000010001100", "0111001100110001", "0011000100010000", "0000100010001100", "0110011001100110", "0011011001101100", "0001011111101000", "0000111111110000", "0111000110001110", "0011100110011100", "0101010101010101", "0000111100001111", "0101101001011010", "0011001111001100", "0011110000111100", "0101010110101010", "0110100101101001", "0101101010100101", "0111001111001110", "0001001111001000", "0011001001001100", "0011101111011100", "0110100110010110", "0011110011000011", "0110011010011001", "0000011001100000", "0100111001000000", "0010011100100000", "0000001001110010", "0000010011100100", "0110110010010011", "0011011011001001", "0110001110011100", "0011100111000110", "0110110011001001", "0110001100111001", "0111111010000001", "0001100011100111", "0000111100110011", "0011001111110000", "0010001011101110", "0100010001110111"];
  const T3 = ["0011001102212222", "0001001122112221", "0000200122112211", "0222002200110111", "0000000011221122", "0011001100220022", "0022002211111111", "0011001122112211", "0000000011112222", "0000111111112222", "0000111122222222", "0012001200120012", "0112011201120112", "0122012201220122", "0011011211221222", "0011200122002220", "0001001101121122", "0111001120012200", "0000112211221122", "0022002200221111", "0111011102220222", "0001000122212221", "0000001101220122", "0000110022102210", "0122012200110000", "0012001211222222", "0110122112210110", "0000011012211221", "0022110211020022", "0110011020022222", "0011012201220011", "0000200022112221", "0000000211221222", "0222002200120011", "0011001200220222", "0120012001200120", "0000111122220000", "0120120120120120", "0120201212010120", "0011220011220011", "0011112222000011", "0101010122222222", "0000000021212121", "0022112200221122", "0022001100220011", "0220122102201221", "0101222222220101", "0000212121212121", "0101010101012222", "0222011102220111", "0002111200021112", "0000211221122112", "0222011101110222", "0002111211120002", "0110011001102222", "0000000021122112", "0110011022222222", "0022001100110022", "0022112211220022", "0000000000002112", "0002000100020001", "0222122202221222", "0101222222222222", "0111201122012220"];
  const A2 = [15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 2, 8, 2, 2, 8, 8, 15, 2, 8, 2, 2, 8, 8, 2, 2, 15, 15, 6, 8, 2, 8, 15, 15, 2, 8, 2, 2, 2, 15, 15, 6, 6, 2, 6, 8, 15, 15, 2, 2, 15, 15, 15, 15, 15, 2, 2, 15];
  const A31 = [3, 3, 8, 3, 8, 3, 3, 8, 8, 8, 6, 6, 6, 5, 3, 3, 3, 3, 8, 3, 3, 3, 6, 8, 3, 8, 6, 6, 8, 5, 10, 8, 8, 3, 3, 5, 6, 8, 8, 10, 6, 3, 8, 5, 3, 6, 6, 8, 3, 3, 5, 5, 5, 8, 5, 10, 5, 10, 8, 13, 3, 12, 3, 3];
  const A32 = [15, 8, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 8, 15, 8, 15, 15, 15, 8, 15, 10, 5, 15, 8, 10, 15, 15, 15, 15, 15, 15, 15, 10, 10, 10, 9, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 8];

  const P2 = T2.map(s => Uint8Array.from(s, c => +c));
  const P3 = T3.map(s => Uint8Array.from(s, c => +c));
  const W2 = [0, 21, 43, 64], W3 = [0, 9, 18, 27, 37, 46, 55, 64];
  const W4 = [0, 4, 9, 13, 17, 21, 26, 30, 34, 38, 43, 47, 51, 55, 60, 64];
  const WT = { 2: W2, 3: W3, 4: W4 };
  // ns, pb, rb, isb, cb, ab, epb, spb, ib, ib2
  const MODES = [
    [3, 4, 0, 0, 4, 0, 1, 0, 3, 0], [2, 6, 0, 0, 6, 0, 0, 1, 3, 0],
    [3, 6, 0, 0, 5, 0, 0, 0, 2, 0], [2, 6, 0, 0, 7, 0, 1, 0, 2, 0],
    [1, 0, 2, 1, 5, 6, 0, 0, 2, 3], [1, 0, 2, 0, 7, 8, 0, 0, 2, 2],
    [1, 0, 0, 0, 7, 7, 1, 0, 4, 0], [2, 6, 0, 0, 5, 5, 1, 0, 2, 0]
  ];

  function decodeBC1(src, w, h, hasAlphaMode) {
    const out = new Uint8Array(w * h * 4), bw = (w + 3) >> 2, bh = (h + 3) >> 2;
    const c = new Uint8Array(16);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      const o = (by * bw + bx) * 8;
      decodeColorBlock(src, o, c, true);
      let bits = (src[o + 4] | (src[o + 5] << 8) | (src[o + 6] << 16) | (src[o + 7] << 24)) >>> 0;
      for (let i = 0; i < 16; i++, bits >>>= 2) {
        const x = bx * 4 + (i & 3), y = by * 4 + (i >> 2);
        if (x >= w || y >= h) continue;
        const k = (bits & 3) * 4, d = (y * w + x) * 4;
        out[d] = c[k]; out[d + 1] = c[k + 1]; out[d + 2] = c[k + 2]; out[d + 3] = c[k + 3];
      }
    }
    return out;
  }
  function decodeColorBlock(s, o, c, withAlpha) {
    const c0 = s[o] | (s[o + 1] << 8), c1 = s[o + 2] | (s[o + 3] << 8);
    const r0 = (c0 >> 11) & 31, g0 = (c0 >> 5) & 63, b0 = c0 & 31;
    const r1 = (c1 >> 11) & 31, g1 = (c1 >> 5) & 63, b1 = c1 & 31;
    const R0 = (r0 << 3) | (r0 >> 2), G0 = (g0 << 2) | (g0 >> 4), B0 = (b0 << 3) | (b0 >> 2);
    const R1 = (r1 << 3) | (r1 >> 2), G1 = (g1 << 2) | (g1 >> 4), B1 = (b1 << 3) | (b1 >> 2);
    c[0] = R0; c[1] = G0; c[2] = B0; c[3] = 255;
    c[4] = R1; c[5] = G1; c[6] = B1; c[7] = 255;
    if (c0 > c1) {
      c[8] = ((2 * R0 + R1) / 3) | 0; c[9] = ((2 * G0 + G1) / 3) | 0; c[10] = ((2 * B0 + B1) / 3) | 0; c[11] = 255;
      c[12] = ((R0 + 2 * R1) / 3) | 0; c[13] = ((G0 + 2 * G1) / 3) | 0; c[14] = ((B0 + 2 * B1) / 3) | 0; c[15] = 255;
    } else {
      c[8] = (R0 + R1) >> 1; c[9] = (G0 + G1) >> 1; c[10] = (B0 + B1) >> 1; c[11] = 255;
      c[12] = 0; c[13] = 0; c[14] = 0; c[15] = withAlpha ? 0 : 255;
    }
  }
  function decodeBC3(src, w, h) {
    const out = new Uint8Array(w * h * 4), bw = (w + 3) >> 2, bh = (h + 3) >> 2;
    const c = new Uint8Array(16), a = new Uint8Array(8), ai = new Uint8Array(16);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      const o = (by * bw + bx) * 16;
      decodeAlphaBlock(src, o, a, ai);
      decodeColorBlock(src, o + 8, c, false);
      let bits = (src[o + 12] | (src[o + 13] << 8) | (src[o + 14] << 16) | (src[o + 15] << 24)) >>> 0;
      for (let i = 0; i < 16; i++, bits >>>= 2) {
        const x = bx * 4 + (i & 3), y = by * 4 + (i >> 2);
        if (x >= w || y >= h) continue;
        const k = (bits & 3) * 4, d = (y * w + x) * 4;
        out[d] = c[k]; out[d + 1] = c[k + 1]; out[d + 2] = c[k + 2]; out[d + 3] = a[ai[i]];
      }
    }
    return out;
  }
  function decodeAlphaBlock(s, o, a, ai) {
    const a0 = s[o], a1 = s[o + 1];
    a[0] = a0; a[1] = a1;
    if (a0 > a1) { for (let i = 1; i < 7; i++) a[i + 1] = (((7 - i) * a0 + i * a1) / 7) | 0; }
    else { for (let i = 1; i < 5; i++) a[i + 1] = (((5 - i) * a0 + i * a1) / 5) | 0; a[6] = 0; a[7] = 255; }
    // 48 bit indeks = 16 x 3 bit
    const lo = (s[o + 2] | (s[o + 3] << 8) | (s[o + 4] << 16)) >>> 0;
    const hi = (s[o + 5] | (s[o + 6] << 8) | (s[o + 7] << 16)) >>> 0;
    for (let i = 0; i < 8; i++) { ai[i] = (lo >>> (i * 3)) & 7; ai[i + 8] = (hi >>> (i * 3)) & 7; }
  }

  function decodeBC7(src, w, h) {
    const out = new Uint8Array(w * h * 4), bw = (w + 3) >> 2, bh = (h + 3) >> 2;
    const px = new Uint8Array(64);
    const ep = new Int32Array(6 * 4);   // [endpoint][r,g,b,a]
    const idx1 = new Uint8Array(16), idx2 = new Uint8Array(16);
    for (let by = 0; by < bh; by++) for (let bx = 0; bx < bw; bx++) {
      decodeBC7Block(src, (by * bw + bx) * 16, px, ep, idx1, idx2);
      for (let i = 0; i < 16; i++) {
        const x = bx * 4 + (i & 3), y = by * 4 + (i >> 2);
        if (x >= w || y >= h) continue;
        const d = (y * w + x) * 4, k = i * 4;
        out[d] = px[k]; out[d + 1] = px[k + 1]; out[d + 2] = px[k + 2]; out[d + 3] = px[k + 3];
      }
    }
    return out;
  }
  function decodeBC7Block(s, o, px, ep, idx1, idx2) {
    let bp = 0;
    function rd(n) { let v = 0; for (let i = 0; i < n; i++, bp++) v |= ((s[o + (bp >> 3)] >> (bp & 7)) & 1) << i; return v; }
    let mode = 0;
    while (mode < 8 && !((s[o] >> mode) & 1)) mode++;
    if (mode >= 8) { px.fill(0); return; }
    bp = mode + 1;
    const [ns, pb, rb, isb, cb, ab, epb, spb, ib, ib2] = MODES[mode];
    const part = rd(pb), rot = rd(rb), isel = rd(isb);
    const ne = ns * 2;
    for (let ch = 0; ch < 3; ch++) for (let e = 0; e < ne; e++) ep[e * 4 + ch] = rd(cb);
    if (ab) for (let e = 0; e < ne; e++) ep[e * 4 + 3] = rd(ab); else for (let e = 0; e < ne; e++) ep[e * 4 + 3] = 255;
    // p-bits
    let cbits = cb, abits = ab;
    if (epb) {
      for (let e = 0; e < ne; e++) {
        const p = rd(1);
        for (let ch = 0; ch < 3; ch++) ep[e * 4 + ch] = (ep[e * 4 + ch] << 1) | p;
        if (ab) ep[e * 4 + 3] = (ep[e * 4 + 3] << 1) | p;
      }
      cbits++; if (ab) abits++;
    } else if (spb) {
      for (let s2 = 0; s2 < ns; s2++) {
        const p = rd(1);
        for (let k = 0; k < 2; k++) for (let ch = 0; ch < 3; ch++) { const i = (s2 * 2 + k) * 4 + ch; ep[i] = (ep[i] << 1) | p; }
      }
      cbits++;
    }
    for (let e = 0; e < ne; e++) {
      for (let ch = 0; ch < 3; ch++) { const v = ep[e * 4 + ch]; ep[e * 4 + ch] = cbits >= 8 ? v : (v << (8 - cbits)) | (v >> (2 * cbits - 8)); }
      if (ab) { const v = ep[e * 4 + 3]; ep[e * 4 + 3] = abits >= 8 ? v : (v << (8 - abits)) | (v >> (2 * abits - 8)); }
    }
    const shape = ns === 1 ? null : (ns === 2 ? P2[part] : P3[part]);
    const an1 = ns === 2 ? A2[part] : (ns === 3 ? A31[part] : -1), an2 = ns === 3 ? A32[part] : -1;
    function readIdx(arr, nb) {
      for (let i = 0; i < 16; i++) {
        const sub = shape ? shape[i] : 0;
        const anchor = i === 0 || (sub === 1 && i === an1) || (sub === 2 && i === an2);
        arr[i] = rd(anchor ? nb - 1 : nb);
      }
    }
    readIdx(idx1, ib);
    if (ib2) readIdx(idx2, ib2);
    for (let i = 0; i < 16; i++) {
      const sub = shape ? shape[i] : 0, e0 = sub * 8, e1 = sub * 8 + 4;
      let ci, ai2, cw, aw;
      if (ib2) {
        // mode 4/5: indeks warna dan alpha terpisah
        const cbi = isel ? ib2 : ib, abi = isel ? ib : ib2;
        ci = isel ? idx2[i] : idx1[i]; ai2 = isel ? idx1[i] : idx2[i];
        cw = WT[cbi][ci]; aw = WT[abi][ai2];
      } else { ci = idx1[i]; cw = aw = WT[ib][ci]; }
      const k = i * 4;
      let r = (ep[e0] * (64 - cw) + ep[e1] * cw + 32) >> 6;
      let g = (ep[e0 + 1] * (64 - cw) + ep[e1 + 1] * cw + 32) >> 6;
      let b = (ep[e0 + 2] * (64 - cw) + ep[e1 + 2] * cw + 32) >> 6;
      let a = ab ? (ep[e0 + 3] * (64 - aw) + ep[e1 + 3] * aw + 32) >> 6 : 255;
      let t;
      if (rot === 1) { t = a; a = r; r = t; } else if (rot === 2) { t = a; a = g; g = t; } else if (rot === 3) { t = a; a = b; b = t; }
      px[k] = r; px[k + 1] = g; px[k + 2] = b; px[k + 3] = a;
    }
  }

  /** Format piksel FTEX: 2=BC1, 4=BC3, 11=BC7 */
  function decode(fmt, src, w, h) {
    switch (fmt) {
      case 2: return decodeBC1(src, w, h, true);
      case 4: return decodeBC3(src, w, h);
      case 11: return decodeBC7(src, w, h);
      default: throw new Error('Format tekstur belum didukung: ' + fmt);
    }
  }
  G.Bcn = { decode, decodeBC1, decodeBC3, decodeBC7 };
  if (typeof module !== 'undefined') module.exports = G.Bcn;
})(typeof globalThis !== 'undefined' ? (globalThis.GF = globalThis.GF || {}) : (window.GF = window.GF || {}));
